<?php
/**
 * General functions used to integrate this theme with WooCommerce.
 *
 * @package suave
 */

?>