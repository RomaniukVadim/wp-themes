<?php
/**
 * @var $id
 * @var $style
 * @var $text
 */


echo do_shortcode('[header_fancy id="' . $id . '" style="' . $style . '" text="' . $text . '" ]');