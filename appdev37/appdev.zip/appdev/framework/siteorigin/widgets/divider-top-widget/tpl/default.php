
<?php
/**
 * @var $style
 */


echo do_shortcode('[divider_top style="' . $style . '"]');