
<?php
/**
 * @var $style
 * @var $class
 * @var $title
 * @var $separator
 * @var $pitch_text
 */


echo do_shortcode('[heading2 class="' . $class . '" style="' . $style . '" title="' . $title . '" separator="' . ($separator ? 'true' : 'false') . '" pitch="' . $pitch_text . '" ]');

