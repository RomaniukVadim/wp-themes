<?php
/**
 * @var $class
 * @var $title
 * @var $text
 */


echo do_shortcode('[toggle type="' . $class . '" title="' . $title . '"]' . $text . '[/toggle]');